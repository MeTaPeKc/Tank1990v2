import pygame
import os
import sys
from pygame.locals import *
from sys import exit

pygame.init()

size = (800, 600)
screen =  pygame.display.set_mode(size,0,32)
pygame.display.set_caption("Map Viewer")

tiles = pygame.sprite.Group()

city = City(self.tiles)

city_size = city.get_size()
self.background = pygame.Surface((self.city_size), 0, 32)
self.background.fill((107,107,107))
clock = pygame.time.Clock()

class City(object):
    def __init__(self, tiles):
        
        self.city =  pygame.image.load("city.png").convert_alpha()
        self.brick = pygame.image.load("brick.png").convert_alpha()
        self.tiles = tiles

        self.x = self.y = 0
        collidable = (255, 0, 0, 255) #add other colors for colidables here, seperated by comas
        self.height = self.city.get_height()
        self.width = self.city.get_width()

        while self.y < self.height:
            color = self.city.get_at((self.x, self.y))
            if color == (collidable):
                self.tiles.add(Tile((self.x*50, self.y*50), self.brick))
                self.x += 1
            if self.x >= self.width:
                self.x = 0
                self.y += 1

    def get_size(self):
        return [self.city.get_size()[0]*50, self.city.get_size()[1]*50]

class Tile(pygame.sprite.Sprite):
    
    def __init__(self, pos, image):

        pygame.sprite.Sprite.__init__(self)
        
        self.rect = image.get_rect(topleft = pos)
        self.rect = Rect(self.rect)
        self.image = image

        self.draw(backgorund)

while true:
     for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        exit()
    self.clock.tick(30)

    self.screen.blit(self.background, (0,0), self.camera)

    pygame.display.flip()

