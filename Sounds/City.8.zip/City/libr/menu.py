import pygame
import os
import sys
from game import *
from data import *
from pygame.locals import *

class Menu:
    def __init__(self, screen):

        self.screen = screen
        self.font = pygame.font.Font(filepath("Abduction II.ttf"), 35)
        self.font2 = pygame.font.Font(filepath("Abduction III.ttf"), 35)
        self.font3 = pygame.font.Font(filepath("Abduction II.ttf"), 50)
        self.option = 1
        self.vehicle = None
        self.veh_pos = (100, 200)
        self.angle = 360
        self.tank= pygame.image.load(filepath("tank2.png")).convert_alpha()
        #self.buggy = pygame.image.load(filepath("buggy.png")).convert_alpha()

    def loop(self):

        while True:

            
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == KEYDOWN:
                    if event.key == K_ESCAPE:
                        pygame.quit()
                        sys.exit()
                    if event.key == K_DOWN:
                        if self.option < 2:
                            self.option += 1
                        else:
                            pass
                    if event.key == K_UP:
                        if self.option > 1:
                            self.option -= 1
                        else:
                            pass
                    if event.key == K_RETURN:
                        if self.option == 1:
                            self.vehicle = "tank"
                            game = Game(self.screen, self.vehicle)
                            game.run()
                        #if self.option == 2:
                            #self.vehicle = "buggy"
                            #game = Game(self.screen, self.vehicle)
                            #game.run()
                        if self.option == 2:
                            pygame.quit()
                            sys.exit()
                                
            ren = self.font3.render("City Tank .7", 1, (255, 0, 0))
            self.screen.blit(ren, (400-ren.get_width()/2 , 50))
            ren = self.font.render("Start", 1, (255, 0, 0))
            self.screen.blit(ren, (400-ren.get_width()/2, 210))
            #ren = self.font.render("Buggy", 1, (255, 0, 0))
            #self.screen.blit(ren, (400-ren.get_width()/2, 270))
            ren = self.font.render("Exit", 1, (255, 0, 0))
            self.screen.blit(ren, (400-ren.get_width()/2, 330))
            if self.option == 1:
                ren = self.font2.render("Start", 1, (0, 230, 0))
                self.screen.blit(ren, (400-ren.get_width()/2, 210))
                self.image = pygame.transform.rotozoom(self.tank, self.angle, 2.0)
                self.screen.blit(self.image, self.veh_pos)
                
            #if self.option == 2:
                #ren = self.font2.render("Buggy", 1, (0, 230, 0))
                #self.screen.blit(ren, (400-ren.get_width()/2, 270))
                #self.image = pygame.transform.rotozoom(self.buggy, self.angle, 2.0)
                #self.screen.blit(self.image, self.veh_pos)
            if self.option == 2:
                ren = self.font2.render("Exit", 1, (0, 230, 0))
                self.screen.blit(ren, (400-ren.get_width()/2, 330))
            
            pygame.display.flip()
            self.screen.fill((0,0,0))
            self.angle += 2
