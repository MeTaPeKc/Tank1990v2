
import sys
import os

try:
    __file__
except NameError:
    pass
else:
    libdir = os.path.abspath(os.path.join(os.path.dirname(__file__), 'libr'))
    sys.path.insert(0, libdir)

sys.path.insert(1, 'libr')
import pygame
from pygame.locals import *
from menu import *



def main():
    pygame.init()
    pygame.display.set_caption("City Tank 0.6")
    screen = pygame.display.set_mode((800,600),0,32)
    menu = Menu(screen)
    menu.loop()

        
import cProfile as profile
profile.run('main()')
